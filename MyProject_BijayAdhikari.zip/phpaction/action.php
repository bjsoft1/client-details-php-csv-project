<?php
if(isset($_POST['add_client_account']))
{
FN_GetClientForm();
exit();
}
else if(isset($_POST['fm_add_client_details_submit']))
{
FN_ClientDataSubmit();
exit();
}
else if(isset($_POST['show_client_data']))
{
FN_GetClientData();
exit();
}
else if(isset($_POST['edit_client_account']))
{
    $id = $_POST['edit_client_account'];
if($id>0)
{
    FN_GetEditClientForm($id);
}
exit();
}
else if(isset($_POST['fm_edit_client_details_submit']))
{
Fn_EditClientFormSubmit();
exit();
}
else if(isset($_POST['show_client_details']))
{
FN_ShowClientDetails();
}
else
{
    echo 'Sorry, Worng Command.';
}



function FN_GetClientForm()
{
 echo'
 <div class="div-server-response-model" id="div-server-response-model">
 <style>body{
 overflow:hidden;
 } 
 </style>
 <div class="div-main-input-body">
 <div class="div-child-head">
 <h2 class="h1-child-head">Add New Client Account</h2>
 <button id="model-btn-close" title="Close" class="button-model-close tthh">X</button>
 </div>
 <br>
 <form class="model-form" id="fm_add_client_details" name="fm_add_client_details" method="POST">
 <div class="div-input-group">
 <label class="lb_input">Full Name <b class="b-color-red">*</b></label>
 <input class="tx_input" type="text" id="tx_name" name="tx_name" placeholder="Full Name *" required maxlength="50">
 <h5 class="msg_error" id="msg_1" name="msg_1"></h5>
 </div>

 <div class="div-input-group">
 <label class="lb_input">Gender <b class="b-color-red">*</b></label>
 <select class="tx_input" name="tx_gender" id="tx_gender">
 <option selected Disabled value="">-----Select Gender-----</option>
 <option value="Male">Male</option>
 <option value="Female">Female</option>
 </select>
 <h5 class="msg_error" id="msg_2" name="msg_2"></h5>
 </div>

 <div class="div-input-group">
 <label class="lb_input">Phone <b class="b-color-red">*</b></label>
 <input class="tx_input" type="text" id="tx_phone" name="tx_phone" placeholder="Phone Number *" required maxlength="15">
 <h5 class="msg_error" id="msg_3" name="msg_3"></h5>
 </div>

 <div class="div-input-group">
 <label class="lb_input">Email <b class="b-color-red">*</b></label>
 <input class="tx_input" type="text" id="tx_email" name="tx_email" placeholder="Email *" required maxlength="50">
 <h5 class="msg_error" id="msg_4" name="msg_4"></h5>
 </div>

 <div class="div-input-group">
 <label class="lb_input">Address <b class="b-color-red">*</b></label>
 <input class="tx_input" type="text" id="tx_address" name="tx_address" placeholder="Address *" required maxlength="15">
 <h5 class="msg_error" id="msg_5" name="msg_5"></h5>
 </div>

 <div class="div-input-group">
 <label class="lb_input">Nationality</label>
 <input class="tx_input" type="text" id="tx_nationality" name="tx_nationality" placeholder="Nationality" maxlength="15">
 <h5 class="msg_error" id="msg_6" name="msg_6"></h5>
 </div>

 <div class="div-input-group">
 <label class="lb_input">Date Of Birth <b class="b-color-red">*</b></label>
 <input class="tx_input" type="text" id="tx_dob" name="tx_dob" placeholder="Date Of Birth *" required>
 <h5 class="msg_error" id="msg_7" name="msg_7"></h5>
 </div>

 <div class="div-input-group">
 <label class="lb_input">Education</label>
 <input class="tx_input" type="text" id="tx_education" name="tx_education" placeholder="Education" maxlength="20">
 <h5 class="msg_error" id="msg_8" name="msg_8"></h5>
 </div>

 <div class="div-input-group">
 <label class="lb_input">Contact Mode <b class="b-color-red">*</b></label>
 <select class="tx_input" name="tx_mode" id="tx_mode">
 <option selected Disabled value="">-----Select Options-----</option>
 <option value="None">None</option>
 <option value="Email">Email</option>
 <option value="Phone">Phone</option>
 </select>
 <h5 class="msg_error" id="msg_9" name="msg_9"></h5>
 </div>

 <div class="div-input-group">
 <input class="btn_input" type="submit" id="btn_submit" name="btn_submit" value="Submit">
 </div>
 <div class="div-input-server-response" id="div-input-server-response">
 </div>
 </form>
 </div>
 <script>
 $(document).ready(function(){
 $("#model-btn-close").click(function() {
 $("#div-server").fadeOut();
 }); 
 $("#fm_add_client_details").submit(function(e) {
 e.preventDefault();
 var name = $("#tx_name").val();
 var gender = $("#tx_gender").val();
 var phone = $("#tx_phone").val();
 var email = $("#tx_email").val();
 var address = $("#tx_address").val();
 //var nationality = $("#tx_nationality").val();
 var dob = $("#tx_dob").val();
 //var education = $("#tx_education").val();
 var mode = $("#tx_mode").val();
 $(".msg_error").html("");
 jQuery("#div-input-server-response").empty();
 if (name == "" || name.length <=4 || name.length>=51) {
 $("#msg_1").html("**Sorry, Full Name Length Error(5-50).**");
 jQuery("#tx_name").focus();
 } else if (gender == "" || gender==null) {
 $("#msg_2").html("**Sorry, Please select gender.**");
 jQuery("#tx_gender").focus();
 } else if (phone == "" || phone.length <=9 || phone.length>=16) {
 $("#msg_3").html("**Sorry, Phone Number Length Error(10-15).**");
 jQuery("#tx_phone").focus();
 } else if (email == "" || email.length <=9 || email.length>=51) {
 $("#msg_4").html("**Sorry, Email Length Error(10-50).**");
 jQuery("#tx_email").focus();
 } else if (email.indexOf("@") <= 0) {
 $("#msg_4").html("**Email ID Not Support (' . "'" . "@').** " . '");'
 . 'jQuery("#tx_email").focus();
 } else if (email.charAt(email.length - 4) != "." && email.charAt(email.length - 3) != ".") {
 $("#msg_4").html("**Email ID Not Support (' . ').**");
 jQuery("#tx_email").focus();
 } else if (address == "" || address.length <=4 || address.length>=51) {
 $("#msg_5").html("**Sorry, Address Length Error(5-50).**");
 jQuery("#tx_address").focus();
 } else if (dob == "" || dob == null) {
 $("#msg_7").html("**Sorry, Please select date of birth.**");
 jQuery("#tx_dob").focus();
 } else if (mode == "" || mode == null) {
 $("#msg_9").html("**Sorry, Please select contact mode.**");
 jQuery("#tx_mode").focus();
 } else {
 jQuery("#btn_submit").val("Saving...");
 jQuery("#btn_submit").attr("disabled", true);
 var formdata = new FormData(this);
 formdata.append("fm_add_client_details_submit", 1);
 $.ajax({
 url: "phpaction/action.php",
 type: "POST",
 data: formdata,
 processData: false,
 contentType: false,
 success: function(response) {
 var res = JSON.parse(response);
 if (res.hasOwnProperty("success")) {
 $("#div-input-server-response").append(divstart1 + res.success + divend);
 setTimeout(function() { window.location.reload(); }, 1000);
 } else if (res.hasOwnProperty("error")) {
 jQuery("#btn_submit").val("Submit");
 jQuery("#btn_submit").attr("disabled", false);
 $("#div-input-server-response").append(divstart2 + res.error + divend);
 } else {
 jQuery("#btn_submit").val("Submit");
 jQuery("#btn_submit").attr("disabled", false);
 $("#div-input-server-response").append(divstart2 + res.error + divend);
 }
 }
 });
 }
 });
});
 </script>
 
 </div>
 ';
 exit();
}

function FN_ClientDataSubmit()
{
    $name = $_POST["tx_name"];
    $gender = $_POST["tx_gender"];
    $phone = $_POST["tx_phone"];
    $email = $_POST["tx_email"];
    $address = $_POST["tx_address"];
    $nationality = $_POST["tx_nationality"];
    $dob = $_POST["tx_dob"];
    $education = $_POST["tx_education"];
    $mode = $_POST["tx_mode"];
    if($name == "")
    {
        echo json_encode(array('error' => "Sorry, Full Name is Required."));
        exit();
    }
    else if($gender == "")
    {
        echo json_encode(array('error' => "Sorry, Gender is Required."));
        exit();
    }
    else if($phone == "")
    {
        echo json_encode(array('error' => "Sorry, Phone Number is Required."));
        exit();
    }
    else if($email == "")
    {
        echo json_encode(array('error' => "Sorry, Email is Required."));
        exit();
    }
    else if($address == "")
    {
        echo json_encode(array('error' => "Sorry, Address is Required."));
        exit();
    }
    else if($dob == "")
    {
        echo json_encode(array('error' => "Sorry, Date Of Birth is Required."));
        exit();
    }
    else if($mode == "")
    {
        echo json_encode(array('error' => "Sorry, Contact Mode is Required."));
        exit();
    }
    else
    {       
           $clientfile = fopen("../data/clientfile.csv",'a');
           $totalrows = count(file("../data/clientfile.csv"));
           if($totalrows > 1)
           {
            $totalrows = ($totalrows - 1) + 1;
           }
           else
           {
            $totalrows = 1;
            $data1 = array(
           
                'id' =>  'ID',
                'name' =>  'Client Name',
                'gender' =>  'Gender',
                'phone' =>  'Phone',
                'email' =>  'Email',
                'address' =>  'Address',
                'nationality' =>  'Nationality',
                'dob' =>  'Date Of Birth',
                'education' =>  'Education',
                'mode' =>  'Contact Mode',
                'datetime' =>  'DateTime',
               );
               fputcsv($clientfile, $data1);
             }
             date_default_timezone_set("Asia/Kathmandu");
             $datetime = date('Y-m-d h:i:s A');
                $data2 = array(
                'ID' =>  $totalrows,
                'name' =>  $name,
                'gender' =>  $gender,
                'phone' =>  $phone,
                'email' =>  $email,
                'address' =>  $address,
                'nationality' =>  $nationality,
                'dob' =>  $dob,
                'education' =>  $education,
                'mode' =>  $mode,
                'datetime' =>  $datetime,
               );
           fputcsv($clientfile, $data2);
           echo json_encode(array('success' => "Client Data Successfully Saved."));
    }
}





function FN_GetClientData()
{
    $limit = $_POST['limit'];
    $search = $_POST['search'];
    $currentpage = $_POST['page'];
    $clientfile = fopen("../data/clientfile.csv",'r');
    $head = 0;
    echo '
    <table class="table-dt-veiw">
 <thead>
 <th>ID</th>
 <th>Full Name</th>
 <th>Gender</th>
 <th>Phone</th>
 <th>Email</th>
 <th>Address</th>
 <th>Action</th>
 <th>DateTime</th>
 </thead>
 <tbody>
 ';
 $i1=0;
 $i2=0;
 $totalrows=0;
    while (($data = fgetcsv($clientfile))!==FALSE)
    {
$TotalRows = count($data);
        if($head!=0)
{
    $i2++;
if($search=="")
{
    if($i1<$limit && $i2>$limit*$currentpage-$limit)
    {
        $i1++;
        echo '
        <tr>
        <td dt="ID">'.$data[0].'</td>
        <td dt="Full Name">'.$data[1].'</td>
        <td dt="Gender">'.$data[2].'</td>
        <td dt="Phone">'.$data[3].'</td>
        <td dt="Email">'.$data[4].'</td>
        <td dt="Address">'.$data[5].'</td>
        <td class="td-flex" dt="Action">
     <button dataid="' . $data[0] .'" class="btn-dt-view btn1" title="Edit Account"><i class="fas fa-edit"></i></button>
     <button dataid="' . $data[0] .'" class="btn-dt-view btn2" title="View Account"><i class="fas fa-eye"></i></button>
        
        </td>
        <td dt="DateTime">'.$data[10].'</td>
        </tr>
        ';
    }
}
else
{
    similar_text($data[1],$search,$percent);
    if($percent>40)
    {
        echo '<tr>
    <td dt="ID">'.$data[0].'</td>
    <td dt="Full Name">'.$data[1].'</td>
    <td dt="Gender">'.$data[2].'</td>
    <td dt="Phone">'.$data[3].'</td>
    <td dt="Email">'.$data[4].'</td>
    <td dt="Address">'.$data[5].'</td>
    <td class="td-flex" dt="Action">
 <button dataid="' . $data[0] .'" class="btn-dt-view btn1" title="Edit Account"><i class="fas fa-edit"></i></button>
 <button dataid="' . $data[0] .'" class="btn-dt-view btn2" title="View Account"><i class="fas fa-eye"></i></button>
    
    </td>
    <td dt="DateTime">'.$data[10].'</td>
    </tr>
    ';
    }
}
}
else
{
    $head = 1;
}
    }
    echo '
 </tbody>
 </table>';
 if($search=="")
 {
    FN_GetPages($limit,$currentpage,$i1,'bpgs',$i2);
 }
 echo'<script>
 $(".btn1").click(function() {
    var id = $(this).attr("dataid");
    FN_GetFormEditClient(id,".btn1");
});
$(".btn2").click(function() {
    var id = $(this).attr("dataid");
    FN_GetClientDetails(id,".btn2");
});
$(".bpgs").click(function() {
    var page = $(this).attr("dataid");
FN_GetClientData(page,"");
FN_GetFormEditClient(id,".btn1");
});
</script>
    ';
}
function FN_GetEditClientForm($id)
{
    $clientfile = fopen("../data/clientfile.csv",'r');
while(($row = fgetcsv($clientfile))!= FALSE)
{
   if($row[0]==$id)
   {
    echo'
    <div class="div-server-response-model" id="div-server-response-model">
    <style>body{
    overflow:hidden;
    } 
    </style>
    <div class="div-main-input-body">
    <div class="div-child-head">
    <h2 class="h1-child-head">Add New Client Account</h2>
    <button id="model-btn-close" title="Close" class="button-model-close tthh">X</button>
    </div>
    <br>
    <form class="model-form" id="fm_edit_client_details" name="fm_edit_client_details" method="POST">
    <div class="div-input-group">
    <label class="lb_input">Full Name <b class="b-color-red">*</b></label>
    <input class="tx_input" type="text" id="tx_name" name="tx_name" value="'.$row['1'].'" placeholder="Full Name *" required maxlength="50">
    <h5 class="msg_error" id="msg_1" name="msg_1"></h5>
    </div>
   
    <div class="div-input-group">
    <label class="lb_input">Gender <b class="b-color-red">*</b></label>
    <select class="tx_input" name="tx_gender" id="tx_gender">
    <option selected Disabled value="">-----Select Gender-----</option>
    <option '; if($row[2]=='Male'){echo 'selected';} echo' value="Male">Male</option>
    <option '; if($row[2]=='Female'){echo 'selected';} echo'  value="Female">Female</option>
    </select>
    <h5 class="msg_error" id="msg_2" name="msg_2"></h5>
    </div>
   
    <div class="div-input-group">
    <label class="lb_input">Phone <b class="b-color-red">*</b></label>
    <input class="tx_input" type="text" id="tx_phone" name="tx_phone" placeholder="Phone Number *" value="'.$row[3].'" required maxlength="15">
    <h5 class="msg_error" id="msg_3" name="msg_3"></h5>
    </div>
   
    <div class="div-input-group">
    <label class="lb_input">Email <b class="b-color-red">*</b></label>
    <input class="tx_input" type="text" id="tx_email" name="tx_email" placeholder="Email *" value="'.$row[4].'" required maxlength="50">
    <h5 class="msg_error" id="msg_4" name="msg_4"></h5>
    </div>
   
    <div class="div-input-group">
    <label class="lb_input">Address <b class="b-color-red">*</b></label>
    <input class="tx_input" type="text" id="tx_address" name="tx_address" placeholder="Address *" value="'.$row[5].'" required maxlength="15">
    <h5 class="msg_error" id="msg_5" name="msg_5"></h5>
    </div>
   
    <div class="div-input-group">
    <label class="lb_input">Nationality</label>
    <input class="tx_input" type="text" id="tx_nationality" name="tx_nationality" placeholder="Nationality" value="'.$row[6].'" maxlength="15">
    <h5 class="msg_error" id="msg_6" name="msg_6"></h5>
    </div>
   
    <div class="div-input-group">
    <label class="lb_input">Date Of Birth <b class="b-color-red">*</b></label>
    <input class="tx_input" type="text" id="tx_dob" name="tx_dob" placeholder="Date Of Birth *" value="'.$row[7].'" required>
    <h5 class="msg_error" id="msg_7" name="msg_7"></h5>
    </div>
   
    <div class="div-input-group">
    <label class="lb_input">Education</label>
    <input class="tx_input" type="text" id="tx_education" name="tx_education" placeholder="Education" value="'.$row[8].'" maxlength="20">
    <h5 class="msg_error" id="msg_8" name="msg_8"></h5>
    </div>
   
    <div class="div-input-group">
    <label class="lb_input">Contact Mode <b class="b-color-red">*</b></label>
    <select class="tx_input" name="tx_mode" id="tx_mode">
    <option selected Disabled value="">-----Select Options-----</option>
    <option '; if($row[9]=='None'){echo 'selected';} echo'  value="None">None</option>
    <option '; if($row[9]=='Email'){echo 'selected';} echo'  value="Email">Email</option>
    <option '; if($row[9]=='Phone'){echo 'selected';} echo'  value="Phone">Phone</option>
    </select>
    <h5 class="msg_error" id="msg_9" name="msg_9"></h5>
    </div>
   
    <div class="div-input-group">
    <input class="btn_input" type="submit" id="btn_submit" name="btn_submit" value="Submit">
    </div>
    <div class="div-input-server-response" id="div-input-server-response">
    </div>
    </form>
    </div>
    <script>
    $(document).ready(function(){
    $("#model-btn-close").click(function() {
    $("#div-server").fadeOut();
    }); 
    $("#fm_edit_client_details").submit(function(e) {
    e.preventDefault();
    var name = $("#tx_name").val();
    var gender = $("#tx_gender").val();
    var phone = $("#tx_phone").val();
    var email = $("#tx_email").val();
    var address = $("#tx_address").val();
    //var nationality = $("#tx_nationality").val();
    var dob = $("#tx_dob").val();
    //var education = $("#tx_education").val();
    var mode = $("#tx_mode").val();
    $(".msg_error").html("");
    jQuery("#div-input-server-response").empty();
    if (name == "" || name.length <=4 || name.length>=51) {
    $("#msg_1").html("**Sorry, Full Name Length Error(5-50).**");
    jQuery("#tx_name").focus();
    } else if (gender == "" || gender==null) {
    $("#msg_2").html("**Sorry, Please select gender.**");
    jQuery("#tx_gender").focus();
    } else if (phone == "" || phone.length <=9 || phone.length>=16) {
    $("#msg_3").html("**Sorry, Phone Number Length Error(10-15).**");
    jQuery("#tx_phone").focus();
    } else if (email == "" || email.length <=9 || email.length>=51) {
    $("#msg_4").html("**Sorry, Email Length Error(10-50).**");
    jQuery("#tx_email").focus();
    } else if (email.indexOf("@") <= 0) {
    $("#msg_4").html("**Email ID Not Support (' . "'" . "@').** " . '");'
    . 'jQuery("#tx_email").focus();
    } else if (email.charAt(email.length - 4) != "." && email.charAt(email.length - 3) != ".") {
    $("#msg_4").html("**Email ID Not Support (' . ').**");
    jQuery("#tx_email").focus();
    } else if (address == "" || address.length <=4 || address.length>=51) {
    $("#msg_5").html("**Sorry, Address Length Error(5-50).**");
    jQuery("#tx_address").focus();
    } else if (dob == "" || dob == null) {
    $("#msg_7").html("**Sorry, Please select date of birth.**");
    jQuery("#tx_dob").focus();
    } else if (mode == "" || mode == null) {
    $("#msg_9").html("**Sorry, Please select contact mode.**");
    jQuery("#tx_mode").focus();
    } else {
    jQuery("#btn_submit").val("Saving...");
    jQuery("#btn_submit").attr("disabled", true);
    var formdata = new FormData(this);
    formdata.append("fm_edit_client_details_submit", '.$id.');
    $.ajax({
    url: "phpaction/action.php",
    type: "POST",
    data: formdata,
    processData: false,
    contentType: false,
    success: function(response) {
    var res = JSON.parse(response);
    if (res.hasOwnProperty("success")) {
    $("#div-input-server-response").append(divstart1 + res.success + divend);
    setTimeout(function() { window.location.reload(); }, 1000);
    } else if (res.hasOwnProperty("error")) {
    jQuery("#btn_submit").val("Submit");
    jQuery("#btn_submit").attr("disabled", false);
    $("#div-input-server-response").append(divstart2 + res.error + divend);
    } else {
    jQuery("#btn_submit").val("Submit");
    jQuery("#btn_submit").attr("disabled", false);
    $("#div-input-server-response").append(divstart2 + res.error + divend);
    }
    }
    });
    }
    });
   });
    </script>
    
    </div>
    ';
 exit();
}
 }
 exit();
}


function Fn_EditClientFormSubmit()
{
    $id = $_POST["fm_edit_client_details_submit"];
    $name = $_POST["tx_name"];
    $gender = $_POST["tx_gender"];
    $phone = $_POST["tx_phone"];
    $email = $_POST["tx_email"];
    $address = $_POST["tx_address"];
    $nationality = $_POST["tx_nationality"];
    $dob = $_POST["tx_dob"];
    $education = $_POST["tx_education"];
    $mode = $_POST["tx_mode"];
    if($id<=0)
    {
        echo json_encode(array('error' => "Sorry, Client ID is Missing."));
        exit();
}
    else if($name == "")
    {
        echo json_encode(array('error' => "Sorry, Full Name is Required."));
        exit();
    }
    else if($gender == "")
    {
        echo json_encode(array('error' => "Sorry, Gender is Required."));
        exit();
    }
    else if($phone == "")
    {
        echo json_encode(array('error' => "Sorry, Phone Number is Required."));
        exit();
    }
    else if($email == "")
    {
        echo json_encode(array('error' => "Sorry, Email is Required."));
        exit();
    }
    else if($address == "")
    {
        echo json_encode(array('error' => "Sorry, Address is Required."));
        exit();
    }
    else if($dob == "")
    {
        echo json_encode(array('error' => "Sorry, Date Of Birth is Required."));
        exit();
    }
    else if($mode == "")
    {
        echo json_encode(array('error' => "Sorry, Contact Mode is Required."));
        exit();
    }
    else
    {       
        $input = "../data/clientfile.csv";
        $output = "../data/temp.csv";
        $readclientfile = fopen($input,'r');
        $writeclientfile = fopen($output,'a');
        while (($row = fgetcsv($readclientfile))!==FALSE)
        {  
               if($row[0]==$id)
               {
                $data1 = array(
                    'ID' =>  $id,
                    'name' =>  $name,
                    'gender' =>  $gender,
                    'phone' =>  $phone,
                    'email' =>  $email,
                    'address' =>  $address,
                    'nationality' =>  $nationality,
                    'dob' =>  $dob,
                    'education' =>  $education,
                    'mode' =>  $mode,
                    'datetime' =>  $row[10],
                   );
               }
               else
               {
                $data1 = array(
                    'ID' =>  $row[0],
                    'name' =>  $row[1],
                    'gender' =>  $row[2],
                    'phone' =>  $row[3],
                    'email' =>  $row[4],
                    'address' =>  $row[5],
                    'nationality' =>  $row[6],
                    'dob' =>  $row[7],
                    'education' =>  $row[8],
                    'mode' =>  $row[9],
                    'datetime' =>  $row[10],
                   );
               }
               fputcsv($writeclientfile, $data1);
            }
            fclose($readclientfile);
        unlink($input);
        fclose($writeclientfile);
        copy($output,$input);
        unlink($output);
           echo json_encode(array('success' => "Client Data Successfully Saved."));
    }    
}


function FN_GetPages($limit,$currentPages,$rowcount,$btnclass,$TotalRows)
{
    if($currentPages<=0)
    {
$currentPages = 1;
    }
    $totalPages = ceil($TotalRows / $limit);
 echo '<div class="pagenumber-div">
<h4><pre class="h4-page-details">Pages '. $totalPages . ' of ' . $currentPages . '      Records '.$TotalRows. ' of ' . $rowcount .'</pre>'.'</h4>
    <ul class="pagenumber-ul">
       ';
if($totalPages <=1)
{
  echo '<li class="pagenumber-li" ><button class="' . $btnclass .' btn_disbled" disabled>' . 'Previous' . '</a></li>';
  echo '<li class="pagenumber-li" ><button class="' . $btnclass .' btn_disbled" disabled>' . 'Next' . '</a></li>';
}
else
{
    if($currentPages<=1)
    {
      echo '<li class="pagenumber-li" ><button class="' . $btnclass .' btn_disbled" disabled dataid="' . '0' . '">' . 'Previous' . '</a></li>';
    }
    else
    {
      echo '<li class="pagenumber-li" ><button class="' . $btnclass .'" dataid="' . $currentPages-1 . '">' . 'Previous' . '</a></li>';
    }
    if($currentPages>=$totalPages)
    {
      echo '<li class="pagenumber-li" ><button class="' . $btnclass .' btn_disbled" disabled dataid="' . '0' . '">' . 'Next' . '</a></li>';
    }
    else
    {
      echo '<li class="pagenumber-li" ><button class="' . $btnclass .'" dataid="' . $currentPages+1 . '">' . 'Next' . '</a></li>';
    }
  for ($i = 1; $i <= $totalPages+1; $i++) {
      if($currentPages - $i >=0 && $currentPages - $i<=10)
      {
         for($ii=0;$ii<=10;$ii++)
         {
           if($currentPages - $ii>0)
           {
           if($i>0 && $i<=$totalPages)
           {
              if($currentPages == $i)
              {
                  echo '<li class="pagenumber-li" ><button class="' . $btnclass .' btn_disbled" disabled dataid="' . $i . '">' . $i . '</a></li>';
              }
              else
              {
                  echo '<li class="pagenumber-li"> <button class="' . $btnclass .'" dataid="' . $i . '">' . $i . '</a></li>';
              }
           }
         $i++;  
         }
         else
         {
          if($i>0 && $i<=$totalPages)
          { if($currentPages == $i)
             {
                 echo '<li class="pagenumber-li" ><button class="' . $btnclass .' btn_disbled" disabled dataid="' . $i . '">' . $i . '</a></li>';
             }
             else
             {
                 echo '<li class="pagenumber-li"> <button class="' . $btnclass .'" dataid="' . $i . '">' . $i . '</a></li>';
             }
          }
         $i++;  
         }
         }                             
      }
      else
      {
         if ($i <= $totalPages) {
             if ($i > 1) {
                 if (($totalPages - $i) > 10) {
                     $i = $i + 10;
                     echo '<li class="pagenumber-li"> <button class="' . $btnclass .'"  dataid="' . $i . '">' . $i . '</a></li>';
                 } else {
                     $i = $totalPages;
                     echo '<li class="pagenumber-li"> <button class="' . $btnclass .'" dataid="' . $i . '">' . $i . '</a></li>';
                 }
             } else {
                 echo '<li class="pagenumber-li"> <button class="' . $btnclass .'" dataid="' . $i . '">' . $i . '</a></li>';
             }
         }
         else
         {
             if($totalPages>1)
             {
                echo '<li class="pagenumber-li"> <button class="' . $btnclass .'" dataid="' . $totalPages . '">Last</a></li>';
             }
         }
      }
     }
}
echo '
    </ul>
</div>                
';
}




function FN_ShowClientDetails()
{
$id = $_POST['show_client_details'];
    $clientfile = fopen("../data/clientfile.csv",'r');
    while(($row = fgetcsv($clientfile))!= FALSE)
    {
       if($row[0]==$id)
       {
          echo '<div class="div-server-response-model" id="div-server-response-model">
        <style>body{
        overflow:hidden;
        } 
        </style>
        <div class="div-main-input-body">
        <h2 class="h1-child-head">Client Details</h2>
        <button id="model-btn-close" title="Close" class="button-model-close tthh">X</button>
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>ID</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$id.'</label>
       </div>
       </div>
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Full Name</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[1].'</label>
       </div>
       </div>
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Gender</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[2].'</label>
       </div>
       </div>
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Phone</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[3].'</label>
       </div>
       </div>

       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Email</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[4].'</label>
       </div>
       </div>
       
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Address</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[5].'</label>
       </div>
       </div>
       
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Nationality</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[6].'</label>
       </div>
       </div>
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Date Of Birth</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[7].'</label>
       </div>
       </div>
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Education</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[8].'</label>
       </div>
       </div>
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>Contact Mode</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[9].'</label>
       </div>
       </div>
       
       <div class="div-details-body">
       <div class="div-details-body-left">
       <label>DateTime</label>
       </div>
       <div class="div-details-body-right">
       <label>'.$row[10].'</label>
       </div>
       </div>
       
       </div>
       </div>
       <script>
       $(document).ready(function(){
           $("#model-btn-close").click(function() {
           $("#div-server").fadeOut();
           }); 
       }); 
       </script>
   ';    
    }
}
}
?>
