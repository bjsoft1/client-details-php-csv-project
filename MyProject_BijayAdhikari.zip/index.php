<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
    <link rel="stylesheet" href="css/style.css" />
</head>
<div class="div-server" id="div-server">









</div>
<body>
<div class="div-full-body-section">
<div class="div-ch-body-section">
        <?php include 'include/searchbox.php'; ?>
<div class="div-head-section">
<h3 class="h3-head">All Client Details</h3>
<button class="add-account-button" id="btn-add-new-acc">Add New</button>
</div>
<div class="div-data-view-body">
</div>
</div>
</div>
</body>
</html>
<style>
    .div-details-body
    {
        display: flex;
        padding: 15px;
        font-size: 13px;
        border-bottom: 2px solid rgb(200, 200, 200);
        background-color: rgba(240,240,240);
    }
    .div-details-body-left
    {
        border-right: 1px solid black;
        width: 110px;
    }
    .div-details-body-right
    {
        width: calc(100% - 110px);
        padding-left: 10px;
    }
</style>
<script type="text/javascript" src="js/main.js"></script>
<script>
// Global Veriables
var ui = '<div class="div-loading"><div class = "loading-ui" ></div></div>';
var divstart1 = '<h3 class="msg_Server_success" id="msg_server" name="msg_server">';
var divstart2 = '<h3 class="msg_Server_error" id="msg_server" name="msg_server">';
var divend = '</h3>';
// Global Veriables


// Call Data Load Function
FN_GetClientData(1,"");
$(document).ready(function() {
    $("#btn-add-new-acc").click(function() {
    $("#div-server").fadeIn();
    $("#div-server").html(ui);
        jQuery("#btn-add-new-acc").attr("disabled", true);
        jQuery("#btn-add-new-acc").val("Loading...");
        $.ajax({
            url: "phpaction/action.php",
            type: "post",
            data: { add_client_account: '1' },
            success: function(response) {
                jQuery("#btn-add-new-acc").val("Add New");
                jQuery("#btn-add-new-acc").attr("disabled", false);
                $("#div-server").fadeIn();
                $("#div-server").html(response);
            }
        })
    });
    $("#tx_limit").change(function() {
        FN_GetClientData(1,"");
    });
    $("#form-search-data").submit(function(e) {
        var search = document.getElementById("tx_search").value;
        e.preventDefault();
        FN_GetClientData(1,search);
    });
});

function FN_GetFormEditClient(id,button)
{
        jQuery(button).attr("disabled", true);
        $.ajax({
            url: "phpaction/action.php",
            type: "post",
            data: { edit_client_account: id },
            success: function(response) {
                jQuery(button).attr("disabled", false);
                $("#div-server").fadeIn();
                $("#div-server").html(response);
            }
        })
    }

    function FN_GetClientDetails(id,button)
{
        jQuery(button).attr("disabled", true);
        $.ajax({
            url: "phpaction/action.php",
            type: "post",
            data: { show_client_details: id },
            success: function(response) {
                jQuery(button).attr("disabled", false);
                $("#div-server").fadeIn();
                $("#div-server").html(response);
            }
        })
    }


//show_client_data
function FN_GetClientData(page,search)
{
    var limit = document.getElementById("tx_limit").value;
    var searchvalue = $("#tx_search").val();
    $(".div-data-view-body").fadeIn();
    $(".div-data-view-body").html(ui);
    $.ajax({
            url: "phpaction/action.php",
            type: "post",
            data: { show_client_data: '1',limit:limit,search:searchvalue,page:page },
            success: function(response) {
                $(".div-data-view-body").fadeIn();
                $(".div-data-view-body").html(response);
            }
        })
}





</script>
<style>
    *
    {
        padding: 0;
        margin: 0;
        font-family: sans-serif;
    }

    .loading-ui {
      border: 8px solid rgb(200, 200, 200);
      /* Light grey */
      border-top: 8px solid rgb(245, 20, 20);
      /* Blue */
      border-radius: 50%;
      width: 30px;
      height: 30px;
      animation: loadingUI 1s linear infinite;
  }
  
  .div-loading {
      width: 100%;
      height: 100px;
      min-width: 100px;
      min-height: 100px;
      display: flex;
      justify-content: center;
      align-items: center;
  }
  
  @keyframes loadingUI {
      0% {
          transform: rotate(0deg);
      }
      100% {
          transform: rotate(360deg);
      }
  }
  

.div-full-body-section
{
padding: 20px 0px;
}
    .div-ch-body-section
    {
margin: 0px auto;
width: 95%;
padding: 10px 0px;
background-color: rgb(240,240,240);
box-shadow: 5px 5px 20px black;

    }
    .div-head-section,.div-search-box-body,.div-data-view-body
    {
        background-color: white;
    }
    .h3-head
    {
padding: 10px;
    }
.add-account-button
{
    background-color: rgb(200, 20, 20);
    color: white;
    float: right;
    width: 100px;
    height: 35px;
    border-radius: 150px;
    border: none;
    font-weight: 600;
    font-size: 15px;
    margin: -27px 10px 0px 0px;
}
.add-account-button:hover,.btn-search:hover
{
    font-size: 16px;
    cursor: pointer;
}
</style>






<style>
 * {
 padding: 0px;
 margin: 0px;
 font-family: sans-serif;
}

.btn_input,
.h1-child-head,
.msg_Server_error
 {
 background-color: rgb(200, 20, 20);
 color: white;
}

.div-main-input-body{
 width: 90%;
 max-width: 900px;
 padding: 0px 0px 10px 0px;
 margin-bottom: 150px;
 border-radius: 10px;
 background-color: white;
 margin: 50px auto; 
}

.h1-child-head {
 padding: 10px 10px 10px 20px;
 border: none;
 font-weight: 100;
 font-size: 18px;
 min-height: 20px;
}
.div-input-group
{
 padding: 20px 30px;
}
.b-color-red {
 color: red;
 font-weight: bold;
 font-size: 20px;
}

.lb_input {
 font-weight: 100;
 font-size: 14px;
}

.tx_input {
 padding: 7px 10px;
 font-size: 13px;
 font-weight: 100;
 width: calc(100% - 130px);
 float: right;
 border-radius: 4px;
 border: none;
 background-color: white;
 border: 1px rgb(200, 190, 190) solid;
 transition: 400ms;
 margin-top: -7px;
}
.msg_error {
 float: right;
 color: red;
 font-weight: bold;
 font-size: 15px;
}

.msg_Server_error,
.msg_Server_success {
 text-align: center;
 padding: 10px;
 color: white;
 max-width: 600px;
 font-weight: bold;
 border-radius: 20px;
 margin: 0px auto;
 font-size: 15px;
}

.msg_Server_success {
 background-color: darkblue;
}

.btn_input
{
 width: 200px;
 height: 40px;
 transition: 250ms;
 font-size: 15px;
 border: none;
 padding: 5px 10px;
 margin-left: 130px;
}

.btn_input:hover {
 background-color: rgb(180, 40, 40);
 font-size: 18px;
 transition: 350ms;
 cursor: pointer;
}
/* For Model */

.div-server-response-model {
 position: fixed;
 max-height: 100vh;
 min-height: 100vh;
 max-width: 100%;
 min-width: 100%;
 margin: 0px auto;
 background-color: rgba(50, 50, 50, .5);
 overflow: hidden;
 z-index: 300;
}

.button-model-close {
 font-size: 30px;
 width: 40px;
 height: 42px;
 border: none;
 float: right;
 margin-top: -42px;
 background-color: rgb(0, 0, 0);
 color: white;
 transition: 200ms;
}

.model-form {
 overflow: auto;
 max-height: calc(100vh - 200px);
}

.button-model-close:hover {
 background-color: red;
 color: black;
 transition: 200ms;
 cursor: pointer;
}


/* For Model */



@media(max-width:750px) {
 .div-main-input-body {
 width: 600px;
 }
 .h1-child-head {
 font-size: 16px;
 }
 .div-input-group {
 padding: 20px 20px;
 }
 .msg_Server_error,
 .msg_Server_success {
 max-width: 90%;
 border-radius: 18px;
 }
 .btn_input {
 margin-left: 130px;
 font-size: 20px;
 }

}


/* **************************************** */

@media(max-width:650px) {
 
 .div-main-input-body {
 width: 90%;
 }
 .h1-child-head {
 font-size: 15px;
 }
 .div-input-group {
 padding: 20px 10px;
 }
 .msg_Server_error,
 .msg_Server_success {
 max-width: 90%;
 border-radius: 18px;
 }
 .btn_input {
 margin-left: 130px;
 font-size: 19px;
 }

}


/* *********************************************** */

@media(max-width:500px) {
 .div-main-input-body {
 width: 92%;
 }
 .h1-child-head {
 font-size: 15px;
 }
 .div-input-group {
 padding: 10px;
 }
 .tx_input {
 width: calc(100%);
 float: none;
 margin-top: 0px;
 }
 .msg_Server_error,
 .msg_Server_success {
 max-width: 90%;
 border-radius: 15px;
 font-size: 12px;
 }
 .btn_input {
 margin-left: 0px;
 }
}

@media(max-width:400px) {
 .btn_input {
 width: 90%;
 margin: 0px auto;
 font-size: 18px;
 }
}

@media(max-width:300px) {
 .div-main-input-body {
 width: 96%;
 min-width: 300px;
 margin: 10px auto;
 }
}
</style>



<style>
.btn-dt-view {
    padding: 5px;
    background-color: white;
    border: 1px solid rgb(220, 220, 220);
    border-radius: 8px;
    font-size: 15px;
    max-width: 30px;
}

.btn-dt-view:hover {
    cursor: pointer;
}

.table-dt-veiw {
    width: 100%;
    margin-top: 0px;
    border-collapse: collapse;
    background-color: white;
}

.table-ft-veiw {
    width: calc(100% - 20px);
    margin: 0px auto;
    border-collapse: collapse;
    background-color: white;
}

th {
    padding: 8px;
    text-align: left;
    font-size: 13px;
}

tr {
    border-bottom: 1px rgb(200, 200, 200) solid;
    height: 30px;
    font-size: 12px;
}

tr:hover {
    background-color: rgb(240, 240, 240);
}

tr:nth-child(even) {
    background-color: rgb(245, 245, 245);
}

td {
    padding: 2px 5px;
    word-break: break-word;
}

.data-view-row-img {
    max-width: 80;
    max-height: 80;
}

.data-icon {
    font-size: 25px;
    padding: 10px;
}

.pagenumber-div {
    display: grid;
    border-bottom: 2px solid rgb(5, 6, 8);
}

.CK_Box:hover {
    cursor: pointer;
}

.pagenumber-div,
.h4-page-details,
.pagenumber-li,
.bpgs {
    background-color: rgb(240, 240, 240);
    color: black;
}

.h4-page-details {
    padding: 5px;
    border-bottom: 1px rgb(100, 100, 100) solid;
    text-align: center;
}

.pagenumber-li {
    display: block;
    float: left;
}

.bpgs {
    border: 1px black solid;
    padding: 5px 10px;
    margin: 5px;
    border-radius: 5px;
    transition: 200ms;
    min-width: 30px;
    font-size: 12px;
}

.bpgs:hover {
    color: black;
    border-color: black;
    transition: 200ms;
    background-color: rgb(230, 230, 230);
    cursor: pointer;
}

.btn_disbled {
    background-color: rgb(200, 200, 200);
    color: black;
    cursor: no-drop;
}

.btn_disbled:hover {
    cursor: no-drop;
}

@media(max-width:800px) {
    thead {
        display: none;
    }
    tr,
    td {
        display: grid;
        width: 100%;
        min-height: 20px;
    }
    .td-flex
    {
        display: flex;
    }
    tr {
        margin-bottom: 15px;
        height: auto;
        border-top: 2px black solid;
        border-bottom: 2px black solid;
        font-size: 11px;
        margin-top: 0px;
    }
    td {
        text-align: left;
        padding-left: 120px;
        position: relative;
        border-bottom: 1px solid rgba(0, 40, 135, 0.2);
        max-width: calc(100% - 125px);
    }
    td::before {
        content: attr(dt);
        position: absolute;
        left: 0;
        width: 90px;
        padding-left: 15px;
        text-align: left;
        border-right: 2px solid rgb(200, 200, 200);
        font-size: 12px;
    }
    .td-action {
        display: block;
    }
}
</style>