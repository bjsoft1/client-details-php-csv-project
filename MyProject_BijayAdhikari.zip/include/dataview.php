<?php

function FN_GetClientData()
{

}



?>