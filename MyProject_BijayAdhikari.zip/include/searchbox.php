<div>
    <form method="POST" id="form-search-data">    
    <div class="div-search-box-body">
         <select class="cb-search" name="tx_limit" id="tx_limit">
             <option Disabled value="0">--Select View Limit--</option>
             <option selected value="10">10</option>
             <option value="20">20</option>
             <option value="50">50</option>
             <option value="100">100</option>
             <option value="500">500</option>
             <i class="fas fa-search"></i><input type="text" class="tx-search" id="tx_search" name="tx_search" maxlength="20" placeholder="Search Client Data">
             <button class="btn-search" id="btn_search_data">Search</button>
        </div>
        </form>
    </div>

    <style>
        .div-search-box-body {
    width: 90%;
    max-width: 600px;
    height: 30px;
    margin: 20px auto;
    box-shadow: 0px 0px 5px black;
    padding: 2px 0px 0px 2px;
    border-radius: 20px;
    overflow: hidden;
}

.cb-search {
    border: none;
    padding: 5px;
    width: 65px;
    border-radius: 20px;
}

.fa-search {
    position: absolute;
    background-color: white;
    margin: 6px 0px 0px 12px;
}

.tx-search {
    width: calc(100% - 150px);
    padding: 4px 5px 5px 30px;
    border-radius: 20px;
    border: none;
}

.btn-search {
    width: 82px;
    height: 35px;
    margin-top: -4px;
    border-radius: 20px;
    border: none;
    background-color: white;
    float: right;
    transition: 200ms;
}

.btn-search:hover {
    cursor: pointer;
    transition: 200ms;
}
    </style>